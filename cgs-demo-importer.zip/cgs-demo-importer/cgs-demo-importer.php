<?php
/**
 * Plugin Name: CGS Demo Importer
 * Description: Import CGS official themes demo content, widgets and theme settings with just one click.
 * Version: 1.0
 * Author: CGS
 * Author URI: https://www.cgsthemes.com/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
define( 'PLUGIN_DIR_PATH', plugin_dir_path(__FILE__));

require_once plugin_dir_path(__FILE__) . 'includes/cgs_demo_importer_sub_page.php';

