<div class="row related-post">
	<div class="col-xl-12">
	<div class="border-bg">	
		<h2>Related Posts</h2>
		<?php
			$blog_args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'post__not_in' => array(1),
			'posts_per_page' => 4
			);

			$blog_data = new WP_Query($blog_args);
			if($blog_data->have_posts()){
		?>	
			<div class="design-wrapper leftside-image">
			<div class="row">
		<?php	
			while($blog_data->have_posts()) : $blog_data->the_post();
		?>
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">		
			<div class="item">
		<?php		
			if(has_post_thumbnail()){
				$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'thumbnail', array( 'class' => 'alignleft' ) );
			} else {
				$post_thumbnail = '';
			}
		?>		
				<a href="<?php echo get_permalink(); ?>"><?php echo $post_thumbnail ?></a>
				<div class="contentpadding">
					<div class="short-post-meta"><?php echo get_the_time('M j, Y') ?></div>
					<h2><a href="<?php echo get_permalink(); ?>"><?php echo get_the_title() ?></a></h2>
				</div>
			</div>
			</div>
		<?php 	
			endwhile;
		?>	
			</div>
			</div>
		
		<?php
			}
			wp_reset_postdata();	
		?>
	</div>	
	</div>
</div>