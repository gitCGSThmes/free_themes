<?php
if ( ! function_exists( 'cgs_lite_pro_setup' ) ) :
	function cgs_lite_pro_setup(){
		load_theme_textdomain( 'cgs-lite-pro', get_template_directory() . '/languages' );
		locate_template( array( 'includes/tgmp/class-tgm-plugin-activation.php' ), true, true );
		locate_template( array( 'includes/customizer.php' ), true, true );
		locate_template( array( 'includes/bs4shortcodes.php' ), true, true );
		register_nav_menus( array(
			'footer_menu'    => __('Footer Menu', 'cgs-lite-pro'),
			'header_top_menu'    => __('Header Top Menu', 'cgs-lite-pro')
		) );
		/* translators: %s: search term */
		register_sidebar( array(
			'name' => __('Footer Widget 1', 'cgs-lite-pro'),
			'id' => 'footer-widget-1',
			'before_widget' => '<div id="%1$s" class="widget_box cgs_widget_box %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="side_title">',
			'after_title' => '</h3>',
		) );
		/* translators: %s: search term */
		register_sidebar( array(
			'name' => __('Footer Widget 2', 'cgs-lite-pro'),
			'id' => 'footer-widget-2',
			'before_widget' => '<div id="%1$s" class="widget_box cgs_widget_box %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="side_title">',
			'after_title' => '</h3>',
		) );
		/* translators: %s: search term */
		register_sidebar( array(
			'name' => __('Footer Widget 3', 'cgs-lite-pro'),
			'id' => 'footer-widget-3',
			'before_widget' => '<div id="%1$s" class="widget_box cgs_widget_box %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="side_title">',
			'after_title' => '</h3>',
		) );
		/* translators: %s: search term */
		register_sidebar( array(
			'name' => __('Contant Page Sidebar', 'cgs-lite-pro'),
			'id' => 'contact-page-sidebar',
			'before_widget' => '<div id="%1$s" class="widget_box cgs_widget_box %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="side_title">',
			'after_title' => '</h3>',
		) );
	}
endif;
add_action( 'after_setup_theme', 'cgs_lite_pro_setup' );
add_action( 'tgmpa_register', 'cgs_lite_pro_require_plugins' );
function cgs_lite_pro_require_plugins(){
	$config = array(
		'id'           => 'cgs-lite-pro-tgmpa', // your unique TGMPA ID
		'default_path' => get_stylesheet_directory() . '/includes/plugins/', // default absolute path
		'menu'         => 'cgs-lite-pro-require-plugins', // menu slug
		'has_notices'  => true, // Show admin notices
		'dismissable'  => false, // the notices are NOT dismissable
		'dismiss_msg'  => '', // this message will be output at top of nag
		'is_automatic' => true, // automatically activate plugins after installation
		'message'      => '<!--Hey there.-->', // message to output right before the plugins table
		'strings'      => array() // The array of message strings that TGM Plugin Activation uses
	);

	$plugins = array(
		array(
			'name'               => 'Contact Form 7',
			'slug'               => 'contact-form-7',
			'required'           => true, // this plugin is required
			'force_activation'   => true, // this plugin is going to stay activated unless the user switches to another theme
		),
		array(
			'name'               => 'Bootstrap 3 Shortcodes',
			'slug'               => 'bootstrap-3-shortcodes',
			'required'           => true, // this plugin is required
			'force_activation'   => true, // this plugin is going to stay activated unless the user switches to another theme
		),
		array(
			'name'               => 'Easy Google Fonts',
			'slug'               => 'easy-google-fonts',
			'required'           => true, // this plugin is required
			'force_activation'   => true, // this plugin is going to stay activated unless the user switches to another theme
		),
		array(
			'name'               => 'Newsletter',
			'slug'               => 'newsletter',
			'required'           => true, // this plugin is required
			'force_activation'   => true, // this plugin is going to stay activated unless the user switches to another theme
		),
		array(
			'name'               => 'Smart Slider 3',
			'slug'               => 'smart-slider-3',
			'required'           => false, // this plugin is required
			'force_activation'   => false, // this plugin is going to stay activated unless the user switches to another theme
		),
		array(
			'name'               => 'WooCommerce',
			'slug'               => 'woocommerce',
			'required'           => true, // this plugin is required
			'force_activation'   => true, // this plugin is going to stay activated unless the user switches to another theme
		),
	);
	tgmpa( $plugins, $config );
}

function cgs_child_pro_enqueue_styles() {
	$parent_style = 'cgs_fashion_trend_style';
	
	wp_enqueue_style( 'cgs-lite-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), true );
	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'cgs_lite_pro_style', get_stylesheet_directory_uri() . '/style.css', array($parent_style ), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_style( 'cgs-lite-infinite-slider-style', get_stylesheet_directory_uri() . '/assets/css/infinite-slider.css', array($parent_style ),  wp_get_theme()->get( 'Version' ) );
	wp_enqueue_style( 'cgs_lite_pro_bxslider', get_stylesheet_directory_uri() . '/assets/css/jquery.bxslider.min.css', array($parent_style ), wp_get_theme()->get( 'Version' ) );


	wp_enqueue_script( 'cgs-lite-slick', get_stylesheet_directory_uri() . '/assets/js/slick.js', array( 'jquery' ), true, true );
	wp_enqueue_script( 'cgs-lite-bxslider', get_stylesheet_directory_uri() . '/assets/js/jquery.bxslider.min.js', array( 'jquery' ), true, true );
	wp_enqueue_script( 'bootstrap_masonry', get_stylesheet_directory_uri() . '/assets/js/bootstrap4.masonry.min.js', array( 'jquery' ), true, true );
	wp_enqueue_script( 'parallax_min_js', get_stylesheet_directory_uri() . '/assets/js/parallax.min.js', array( 'jquery' ), true, true );
	wp_enqueue_script( 'cgs-lite-themescript', get_stylesheet_directory_uri() . '/assets/js/themescript.js', array( 'jquery' ), true, true );
}
add_action( 'wp_enqueue_scripts', 'cgs_child_pro_enqueue_styles' );

add_filter( 'body_class', 'cgs_custom_class' );

function excerpt($limit) {
	$excerpt = explode(' ', get_the_excerpt(), $limit);
	if (count($excerpt)>=$limit) {
		array_pop($excerpt);
		$excerpt = implode(" ",$excerpt).'...';
	} else {
		$excerpt = implode(" ",$excerpt);
	}
	$excerpt = preg_replace('`[[^]]*]`','',$excerpt);
	return $excerpt;
}

function cgs_custom_class( $classes ) {
	/*$cgs_page_layout = esc_html(get_post_meta(get_the_ID(), 'cgs_fashion_trend_page_layout', true));

	if($cgs_page_layout == 'left_sidebar'){
		$classes[] = 'page-left-sidebar';
	}
	if($cgs_page_layout == 'no_sidebar_full_width'){
		$classes[] = 'no-sidebar-full-width';
	}*/

	if ( is_page_template() ) {
		$classes[] = 'jags';
	}
	return $classes;
}
function iap_wc_bootstrap_form_field_args ($args, $key, $value) { 
  $args['input_class'][] = 'form-control'; 
  return $args; 
}
add_filter('woocommerce_form_field_args','iap_wc_bootstrap_form_field_args', 10, 3);