<?php /* Template Name: Full Wide */ ?>
<?php get_header(); ?>
<?php
$cgs_flower_shop_show_inner_banner = get_post_meta(get_the_ID(), 'cgs_flower_shop_show_inner_banner', true);
$cgs_flower_shop_banner_image = get_field('cgs_flower_shop_banner_image');
$cgs_flower_shop_title_on_banner = get_post_meta(get_the_ID(), 'cgs_flower_shop_title_on_banner', true);
$cgs_flower_shop_title_color = get_post_meta(get_the_ID(), 'cgs_flower_shop_title_color', true);
$cgs_flower_shop_title_alignment = get_post_meta(get_the_ID(), 'cgs_flower_shop_title_alignment', true);
?>

<?php if($cgs_flower_shop_show_inner_banner == 'yes' || $cgs_flower_shop_show_inner_banner == ''){ ?>
    <div class="inner-banner" style="background: url('<?php echo $cgs_flower_shop_banner_image; ?>')">
        <div class="container">
            <h1 style="color: <?php echo $cgs_flower_shop_title_color; ?>; text-align: <?php echo $cgs_flower_shop_title_alignment; ?>;"><?php echo $cgs_flower_shop_title_on_banner; ?></h1>
        </div>
    </div>
    <style>
        .inner-banner h1:after{
            border-top: 1px solid <?php echo $cgs_flower_shop_title_color; ?>;
        }
    </style>
<?php } ?>
    <div class="main-content-wrapper">
		<?php if(have_posts()){ ?>
			<?php while(have_posts()) : the_post(); ?>
                <?php if(empty($cgs_flower_shop_title_on_banner)){ ?>
                <h1><?php the_title(); ?></h1>
				<?php } ?>
				<?php get_template_part( 'content' ); ?>
			<?php endwhile; ?>
		<?php } ?>
    </div>
<?php get_footer(); ?>
