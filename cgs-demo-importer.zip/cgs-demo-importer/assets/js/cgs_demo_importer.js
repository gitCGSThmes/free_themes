jQuery(document).ready(function(){
    jQuery(document).on('click', 'a.active-theme', function(e) {
        e.preventDefault();
        var this_element = jQuery(this);
        var active_theme_name = this_element.data('active-theme-name');
        var cgsloading = this_element.data('cgsloading');
        var impbutton = this_element.data('impbutton');
        var theme_thumb_overlay = this_element.data('theme_thumb_overlay');

        jQuery('.importing_progress').hide();
        jQuery('.data_imported').hide();
        jQuery('.media_imported').hide();
        jQuery('.widget_imported').hide();
        jQuery('.import_completed').hide();

        jQuery.confirm({
            title: 'Alert!',
            content: 'Please take a back up your website data, clicking on Confirm button will remove your previous theme and its data.',
            buttons: {
                confirm: function () {
                    jQuery('.theme_thumb_overlay').hide();
                    jQuery('.'+cgsloading).show();
                    jQuery('.'+impbutton).hide();
                    jQuery('.'+theme_thumb_overlay).show();
                    jQuery('.cgs_import_demo_success').hide();
                    jQuery('.cgs_import_demo_error').hide();
                    jQuery('.importing_progress').show();
                    jQuery.ajax({
                        url : cgs_demo_importer_obj.ajax_url,
                        type : 'post',
                        data : {
                            action : 'cgs_demo_importer_function',
                            active_theme_name: active_theme_name
                        },
                        success : function( response ) {
                            console.log(response);
                            if(response == 'ok'){
                                jQuery('.importing_progress').hide();
                                jQuery('.data_imported').show();
                                setTimeout(function(){
                                    jQuery('.media_imported').show();
                                }, 100);
                                //window.scrollTo(0, 0);
                                setTimeout(function(){
                                    jQuery('.widget_imported').show();
                                }, 2000);

                                jQuery('.cgs_import_demo_success').show();
                                var success_html_code = '<div class="notice notice-success is-dismissible">\n' +
                                    '                       <p><strong>Demo data successfully imported.</strong></p>\n' +
                                    '                      </div>';
                                jQuery('.cgs_import_demo_success').html(success_html_code);
                                setTimeout(function(){
                                    jQuery('.'+cgsloading).hide();
                                    jQuery('.import_completed').show();
                                    jQuery('.'+impbutton).show();
                                }, 2000);
                            } else {
                                jQuery('.cgs_import_demo_error').show();
                                var error_html_code = '<div class="notice notice-error is-dismissible">\n' +
                                    '                       <p><strong>'+response+'</strong></p>\n' +
                                    '                      </div>';
                                jQuery('.cgs_import_demo_error').html(error_html_code);

                                setTimeout(function(){
                                    jQuery('.importing_progress').hide();
                                    jQuery('.'+cgsloading).hide();
                                    //jQuery('.import_completed').show();
                                    jQuery('.'+impbutton).show();
                                }, 2000);
                            }
                        }
                    });
                },
                cancel: function () {
                    //jQuery.alert('Canceled!');
                },
            }
        });
        console.log(cgsloading);
    });
});
