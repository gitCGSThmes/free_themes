<div class="row related-post">
	<div class="col-xl-12">
		<div class="block-title">
			<h2>Related Posts</h2>
			<div class="divider"></div>
		</div>
		<?php echo do_shortcode('[cgs-lite-blog-listng blog_style="grid" column ="2" number_of_posts="4"][/cgs-lite-blog-listng]'); ?>
	</div>
</div>