<?php
/* @var $fields NewsletterFields */
?>


<?php $fields->text('view', 'View online label') ?>
<?php $fields->text('profile', 'Subscription details label') ?>

<?php $fields->font() ?>

<?php $fields->block_commons() ?>
