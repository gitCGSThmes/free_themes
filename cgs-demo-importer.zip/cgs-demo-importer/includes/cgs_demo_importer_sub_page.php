<?php
define('PLUGIN_PATH', plugins_url('',dirname(__FILE__)));

require_once ABSPATH . 'wp-admin/includes/import.php';
require_once ABSPATH . 'wp-admin/includes/class-wp-importer.php';
require_once PLUGIN_DIR_PATH . 'includes/importer/class-wxr-importer.php';
require_once PLUGIN_DIR_PATH . 'includes/importer/class-wxr-parsers.php';

add_action('admin_menu','create_plugin_page');
add_action( 'init', 'cgs_lite_pro_create_post_type' );
add_action('admin_enqueue_scripts', 'cgs_demo_importer_enqueue_scripts');
add_action( 'wp_enqueue_scripts', 'cgs_demo_importer_enqueue_css' );
add_action('wp_ajax_cgs_demo_importer_function', 'cgs_demo_importer_function');
add_action('wp_ajax_cgs_demo_importer_message', 'cgs_demo_importer_message');

function create_plugin_page(){
	add_theme_page( 'Demo Importer', 'Demo Importer', 'manage_options', 'demo-importer', 'cge_demo_importer_page');
}
function cge_demo_importer_page(){
	$active_theme_data = wp_get_theme();
	$active_theme = esc_html( $active_theme_data->get( 'TextDomain' ) );
	$cgs_lite_free_themes = array('default', 'travel', 'pharmacy');
	$cgs_lite_free_theme_names = array('Default', 'Travel', 'Pharmacy');
	$cgs_lite_pro_themes_url = array(
		'https://cgsthemesdemo.com/cgs-lite-pro/fashion/',
		'https://cgsthemesdemo.com/cgs-lite-pro/travel/',
		'https://cgsthemesdemo.com/cgs-lite-pro/pharmacy/'
	);

	/* Elementor supported themes */
	$elementor_supported_themes = array('corporate', 'delivery-service', 'diner', 'event-planner', 'newspaper');
	$elementor_supported_theme_names = array('Corporate', 'Delivery Service', 'Diner', 'Event Planner', 'Newspaper');
	$elementor_supported_themes_url = array(
		'https://cgsthemesdemo.com/corporate',
		'https://cgsthemesdemo.com/delivery-service',
		'https://cgsthemesdemo.com/diner',
		'https://cgsthemesdemo.com/event-planner',
        'https://cgsthemesdemo.com/newspaper'
	);

	$cgs_lite_free_themes_repo = 'https://cgsthemes.com/repo/themes';
	?>
    <div class="wrap">
        <h2>Demo Importer</h2>
        <div class="cgs_import_demo_success"></div>
        <div class="cgs_import_demo_error"></div>
        <div class="demo-importer-wrapper">
			<div class="notice notice-success">
                <p>Thank you for using our theme. You can import our demo sites or set up the website from scratch.</p>
            </div>
            <div class="notice notice-error">
                <p>NOTICE: Please keep backup before importing data.</p>
            </div>
            <h3>CGS Lite Elementor Themes</h3>
            <style>
                .theme_thumb{
                    position: relative;
                }
                .theme_thumb_overlay{
                    position: absolute;
                    top: 0;
                    right: 0;
                    bottom: 0;
                    left: 0;
                    border: 1px solid #CCC;
                    padding: 5px;
                    border-radius: 4px;
                    box-shadow: 0px 0px 10px 0px #ccc;
                    width: 300px;
                    height: 226px;
                    background: rgba(0, 0, 0, 0.8);
                    display: none;
                }
                .importing_progress{
                    color: #FFFFFF;
                    padding: 30px 0 10px 0px;
                    display: none;
                    text-align: center;
                }
                .data_imported{
                    color: #FFFFFF;
                    padding: 30px 0 10px 50px;
                    display: none;
                }
                .media_imported{
                    color: #FFFFFF;
                    padding: 0px 0 10px 50px;
                    display: none;
                }
                .widget_imported{
                    color: #FFFFFF;
                    padding: 0px 0 10px 50px;
                    display: none;
                }
                .import_completed{
                    color: #FFFFFF;
                    text-align: center;
                    padding: 10px 0 0px 0px;
                    display: none;
                }
                .cgsloading{
                    text-align: center;
                    padding: 10px 0 0px 0px;
                }

                svg {
                    width: 40px;
                    display: block;
                    margin: 20px auto 0;
                }
                .path {
                    stroke-dasharray: 1000;
                    stroke-dashoffset: 0;
                }
                .path.circle {
                    -webkit-animation: dash 0.9s ease-in-out;
                    animation: dash 0.9s ease-in-out;
                }
                .path.line {
                    stroke-dashoffset: 1000;
                    -webkit-animation: dash 0.9s 0.35s ease-in-out forwards;
                    animation: dash 0.9s 0.35s ease-in-out forwards;
                }
                .path.check {
                    stroke-dashoffset: -100;
                    -webkit-animation: dash-check 0.9s 0.35s ease-in-out forwards;
                    animation: dash-check 0.9s 0.35s ease-in-out forwards;
                }
                @-webkit-keyframes dash {
                    0% {
                        stroke-dashoffset: 1000;
                    }
                    100% {
                        stroke-dashoffset: 0;
                    }
                }
                @keyframes dash {
                    0% {
                        stroke-dashoffset: 1000;
                    }
                    100% {
                        stroke-dashoffset: 0;
                    }
                }
                @-webkit-keyframes dash-check {
                    0% {
                        stroke-dashoffset: -100;
                    }
                    100% {
                        stroke-dashoffset: 900;
                    }
                }
                @keyframes dash-check {
                    0% {
                        stroke-dashoffset: -100;
                    }
                    100% {
                        stroke-dashoffset: 900;
                    }
                }
                .demo-importer-wrapper ul li{
                    vertical-align: top;
                }
                .lds-spinner {
                    color: official;
                    display: inline-block;
                    position: relative;
                    width: 64px;
                    height: 64px;
                }
                .lds-spinner div {
                    transform-origin: 32px 32px;
                    animation: lds-spinner 1.2s linear infinite;
                }
                .lds-spinner div:after {
                    content: " ";
                    display: block;
                    position: absolute;
                    top: 3px;
                    left: 29px;
                    width: 5px;
                    height: 14px;
                    border-radius: 20%;
                    background: #fff;
                }
                .lds-spinner div:nth-child(1) {
                    transform: rotate(0deg);
                    animation-delay: -1.1s;
                }
                .lds-spinner div:nth-child(2) {
                    transform: rotate(30deg);
                    animation-delay: -1s;
                }
                .lds-spinner div:nth-child(3) {
                    transform: rotate(60deg);
                    animation-delay: -0.9s;
                }
                .lds-spinner div:nth-child(4) {
                    transform: rotate(90deg);
                    animation-delay: -0.8s;
                }
                .lds-spinner div:nth-child(5) {
                    transform: rotate(120deg);
                    animation-delay: -0.7s;
                }
                .lds-spinner div:nth-child(6) {
                    transform: rotate(150deg);
                    animation-delay: -0.6s;
                }
                .lds-spinner div:nth-child(7) {
                    transform: rotate(180deg);
                    animation-delay: -0.5s;
                }
                .lds-spinner div:nth-child(8) {
                    transform: rotate(210deg);
                    animation-delay: -0.4s;
                }
                .lds-spinner div:nth-child(9) {
                    transform: rotate(240deg);
                    animation-delay: -0.3s;
                }
                .lds-spinner div:nth-child(10) {
                    transform: rotate(270deg);
                    animation-delay: -0.2s;
                }
                .lds-spinner div:nth-child(11) {
                    transform: rotate(300deg);
                    animation-delay: -0.1s;
                }
                .lds-spinner div:nth-child(12) {
                    transform: rotate(330deg);
                    animation-delay: 0s;
                }
                @keyframes lds-spinner {
                    0% {
                        opacity: 1;
                    }
                    100% {
                        opacity: 0;
                    }
                }

            </style>
            <ul>
				<?php if(!empty($cgs_lite_free_themes)){ ?>
					<?php $i = 0; ?>
					<?php foreach($cgs_lite_free_themes as $cgs_lft){ ?>
                        <li>
                            <div class="theme_thumb">
                                <div class="theme_thumb_overlay theme_thumb_overlay_<?php echo $cgs_lft; ?>">
                                    <div class="importing_progress">Please wait, Data import is in progress</div>
                                    <div class="data_imported"><span class="dashicons dashicons-yes"></span> Data Imported</div>
                                    <div class="media_imported"><span class="dashicons dashicons-yes"></span> Media Imported</div>
                                    <div class="widget_imported"><span class="dashicons dashicons-yes"></span> Widget Imported</div>
                                    <div class="cgsloading cgsloading_<?php echo $cgs_lft; ?>">
                                        <div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
                                    </div>
                                    <div class="import_completed">
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2">
                                            <circle class="path circle" fill="none" stroke="#1db05f" stroke-width="8" stroke-miterlimit="10" cx="65.1" cy="65.1" r="62.1"/>
                                            <polyline class="path check" fill="none" stroke="#1db05f" stroke-width="8" stroke-linecap="round" stroke-miterlimit="10" points="100.2,40.2 51.5,88.8 29.8,67.5 "/>
                                        </svg>
                                    </div>
                                </div>
                                <img src="<?php echo PLUGIN_PATH.'/includes/repo/themes/cgs-lite/'.$cgs_lft.'/screenshot.jpg' ?>">
                            </div>
                            <div class="themename themename_<?php echo $cgs_lft; ?>"><?php echo $cgs_lite_free_theme_names[$i]; ?></div>
                            <div class="impbutton impbutton_<?php echo $cgs_lft; ?>"><a href="javascript:void(0);" class="button button-primary active-theme" data-active-theme-name="<?php echo $cgs_lft; ?>" data-cgsloading="cgsloading_<?php echo $cgs_lft; ?>" data-impbutton="impbutton_<?php echo $cgs_lft; ?>" data-theme_thumb_overlay="theme_thumb_overlay_<?php echo $cgs_lft; ?>">Import Free Theme</a> <a href="<?php echo $cgs_lite_pro_themes_url[$i]; ?>" class="button button-primary" target="_blank">View Demo</a></div>
                        </li>
						<?php $i++; ?>
					<?php } ?>
				<?php } ?>

				<?php if(!empty($elementor_supported_themes)){ ?>
					<?php $i = 0; ?>
					<?php foreach($elementor_supported_themes as $est){ ?>
                        <li>
                            <div class="theme_thumb">
                                <div class="theme_thumb_overlay theme_thumb_overlay_<?php echo $est; ?>">
                                    <div class="importing_progress">Please wait, Data import is in progress</div>
                                    <div class="data_imported"><span class="dashicons dashicons-yes"></span> Data Imported</div>
                                    <div class="media_imported"><span class="dashicons dashicons-yes"></span> Media Imported</div>
                                    <div class="widget_imported"><span class="dashicons dashicons-yes"></span> Widget Imported</div>
                                    <div class="cgsloading cgsloading_<?php echo $est; ?>">
                                        <div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
                                    </div>
                                    <div class="import_completed">
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2">
                                            <circle class="path circle" fill="none" stroke="#73AF55" stroke-width="6" stroke-miterlimit="10" cx="65.1" cy="65.1" r="62.1"/>
                                            <polyline class="path check" fill="none" stroke="#73AF55" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" points="100.2,40.2 51.5,88.8 29.8,67.5 "/>
                                        </svg>
                                    </div>
                                </div>
                                <img src="<?php echo PLUGIN_PATH.'/includes/repo/themes/elementor/'.$est.'/screenshot.jpg' ?>">
                            </div>
                            <div class="themename"><?php echo $elementor_supported_theme_names[$i]; ?></div>
                            <?php if($est != 'newspaper'){ ?>
                            <div class="impbutton impbutton_<?php echo $est; ?>"><a href="javascript:void(0);" class="button button-primary active-theme" data-active-theme-name="<?php echo $est; ?>" data-cgsloading="cgsloading_<?php echo $est; ?>" data-impbutton="impbutton_<?php echo $est; ?>" data-theme_thumb_overlay="theme_thumb_overlay_<?php echo $est; ?>">Import Free Theme</a> <a href="<?php echo $elementor_supported_themes_url[$i]; ?>" class="button button-primary" target="_blank">View Demo</a></div>
                            <?php } else { ?>
                                <div class="impbutton impbutton_<?php echo $est; ?>"><a href="<?php echo $elementor_supported_themes_url[$i]; ?>" class="button button-primary" target="_blank">View Demo</a></div>
                            <?php } ?>
                        </li>
						<?php $i++; ?>
					<?php } ?>
				<?php } ?>
            </ul>
			<?php /*} else { */?><!--
                <p class="notice notice-error">The Theme Demo Import plugin require an active CGS theme</p>
            --><?php /*} */?>
        </div>
    </div>
	<?php
}
function cgs_lite_pro_create_post_type() {
	$our_team_labels = array(
		'name' => esc_html__('Our Team', 'cgs-lite-pro'),
		'singular_name' => esc_html__('Our Team', 'cgs-lite-pro'),
		'add_new' => esc_html__('Add New', 'cgs-lite-pro'),
		'add_new_item' => esc_html__('Add New Team', 'cgs-lite-pro'),
		'edit_item' => esc_html__('Edit Team', 'cgs-lite-pro'),
		'new_item' => esc_html__('New Team', 'cgs-lite-pro'),
		'view_item' => esc_html__('View Team', 'cgs-lite-pro'),
		'search_items' => esc_html__('Search Team', 'cgs-lite-pro'),
		'not_found' => esc_html__('Nothing found', 'cgs-lite-pro'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'cgs-lite-pro'),
		'parent_item_colon' => ''
	);
	$our_team_args = array(
		'labels' => $our_team_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => 'dashicons-admin-tools',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title','editor','thumbnail')
	);
	register_post_type( 'cgs-our-team' , $our_team_args );

	$our_clients_labels = array(
		'name' => esc_html__('Our Clients', 'cgs-lite-pro'),
		'singular_name' => esc_html__('Our Client', 'cgs-lite-pro'),
		'add_new' => esc_html__('Add Client', 'cgs-lite-pro'),
		'add_new_item' => esc_html__('Add New Client', 'cgs-lite-pro'),
		'edit_item' => esc_html__('Edit Client', 'cgs-lite-pro'),
		'new_item' => esc_html__('New Client', 'cgs-lite-pro'),
		'view_item' => esc_html__('View Client', 'cgs-lite-pro'),
		'search_items' => esc_html__('Search Client', 'cgs-lite-pro'),
		'not_found' => esc_html__('Nothing found', 'cgs-lite-pro'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'cgs-lite-pro'),
		'parent_item_colon' => ''
	);
	$our_clients_args = array(
		'labels' => $our_clients_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => 'dashicons-admin-tools',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title','editor','thumbnail')
	);
	register_post_type( 'cgs-our-clients' , $our_clients_args );

	$testimonial_labels = array(
		'name' => esc_html__('Testimonials', 'cgs-lite-pro'),
		'singular_name' => esc_html__('Testimonial', 'cgs-lite-pro'),
		'add_new' => esc_html__('Add New', 'cgs-lite-pro'),
		'add_new_item' => esc_html__('Add New Testimonial', 'cgs-lite-pro'),
		'edit_item' => esc_html__('Edit Testimonial', 'cgs-lite-pro'),
		'new_item' => esc_html__('New Testimonial', 'cgs-lite-pro'),
		'view_item' => esc_html__('View Testimonial', 'cgs-lite-pro'),
		'search_items' => esc_html__('Search Testimonial', 'cgs-lite-pro'),
		'not_found' => esc_html__('Nothing found', 'cgs-lite-pro'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'cgs-lite-pro'),
		'parent_item_colon' => ''
	);
	$testimonial_args = array(
		'labels' => $testimonial_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => 'dashicons-admin-tools',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title','editor','thumbnail')
	);
	register_post_type( 'cgs-testimonials' , $testimonial_args );

	$services_labels = array(
		'name' => esc_html__('Services', 'cgs-lite-pro'),
		'singular_name' => esc_html__('Service', 'cgs-lite-pro'),
		'add_new' => esc_html__('Add New', 'cgs-lite-pro'),
		'add_new_item' => esc_html__('Add New Service', 'cgs-lite-pro'),
		'edit_item' => esc_html__('Edit Service', 'cgs-lite-pro'),
		'new_item' => esc_html__('New Service', 'cgs-lite-pro'),
		'view_item' => esc_html__('View Service', 'cgs-lite-pro'),
		'search_items' => esc_html__('Search Service', 'cgs-lite-pro'),
		'not_found' => esc_html__('Nothing found', 'cgs-lite-pro'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'cgs-lite-pro'),
		'parent_item_colon' => ''
	);
	$services_args = array(
		'labels' => $services_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => 'dashicons-admin-tools',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title')
	);
	register_post_type( 'cgs-services' , $services_args );

	$cgs_pricing_table_labels = array(
		'name' => esc_html__('Pricing Table', 'cgs-lite-pro'),
		'singular_name' => esc_html__('Pricing Table', 'cgs-lite-pro'),
		'add_new' => esc_html__('Add New', 'cgs-lite-pro'),
		'add_new_item' => esc_html__('Add New Pricing Table', 'cgs-lite-pro'),
		'edit_item' => esc_html__('Edit Pricing Table', 'cgs-lite-pro'),
		'new_item' => esc_html__('New Pricing Table', 'cgs-lite-pro'),
		'view_item' => esc_html__('View Pricing Table', 'cgs-lite-pro'),
		'search_items' => esc_html__('Search Pricing Table', 'cgs-lite-pro'),
		'not_found' => esc_html__('Nothing found', 'cgs-lite-pro'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'cgs-lite-pro'),
		'parent_item_colon' => ''
	);
	$cgs_pricing_table_args = array(
		'labels' => $cgs_pricing_table_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => 'dashicons-admin-tools',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title')
	);
	register_post_type( 'cgs-pricing-table' , $cgs_pricing_table_args );
}
function cgs_demo_importer_enqueue_scripts(){
	wp_enqueue_script( 'cgs-jquery-confirm-min-js', PLUGIN_PATH. '/assets/js/jquery-confirm.min.js', array('jquery'));
	wp_enqueue_style( 'jquery-confirm-min-css', PLUGIN_PATH. '/assets/css/jquery-confirm.min.css');
	wp_enqueue_script( 'cgs-demo-importer-js', PLUGIN_PATH. '/assets/js/cgs_demo_importer.js', array('jquery'));
	wp_localize_script( 'cgs-demo-importer-js', 'cgs_demo_importer_obj', array( 'ajax_url' => admin_url('admin-ajax.php')) );
}
function cgs_demo_importer_enqueue_css(){
	wp_enqueue_style( 'cgs-demo-importer-css', PLUGIN_PATH. '/assets/css/cgs-demo-importer.css');
}
function auto_add_sidebar_widgets( $add_to_sidebar = array(), $ignore_sidebar_with_content = true ){
	if(empty($add_to_sidebar)){
		return;
	}
	$sidebar_options = get_option('sidebars_widgets');
	foreach($add_to_sidebar as $sidebar_id => $widgets){
		//** do not add widgets if sidebar already has content
		if ( ! empty( $sidebar_options[$sidebar_id] ) && $ignore_sidebar_with_content) {
			continue;
		}
		foreach ($widgets as $index => $widget){
			$widget_id_base      = $widget['id_base'];
			$widget_instance  = $widget['instance'];
			$widget_instances = get_option('widget_'.$widget_id_base);
			if(!is_array($widget_instances)){
				$widget_instances = array();
			}
			$count = count($widget_instances)+1;
			$sidebar_options[$sidebar_id][] = $widget_id_base.'-'.$count;
			$widget_instances[$count] = $widget_instance;
			//** save widget options
			update_option('widget_'.$widget_id_base,$widget_instances);
		}
	}
	//** save sidebar options:
	update_option('sidebars_widgets',$sidebar_options);
}

function deleteDirectory($dir) {
	if (!file_exists($dir)) { return true; }
	if (!is_dir($dir) || is_link($dir)) {
		return unlink($dir);
	}
	foreach (scandir($dir) as $item) {
		if ($item == '.' || $item == '..') { continue; }
		if (!deleteDirectory($dir . "/" . $item, false)) {
			chmod($dir . "/" . $item, 0777);
			if (!deleteDirectory($dir . "/" . $item, false)) return false;
		};
	}
	return rmdir($dir);
}
function clean_data(){
	$post_args = array(
		'post_type' => array('post', 'page', 'cgs-our-team', 'cgs-our-clients', 'cgs-testimonials', 'cgs-services', 'cgs-pricing-table', 'attachment', 'revision'),
		'post_status' => 'any',
		'posts_per_page' => -1
	);

	$post_data = new WP_Query($post_args);
	while($post_data->have_posts()) : $post_data->the_post();
		wp_delete_post(get_the_ID(), true);
	endwhile;
	wp_reset_postdata();
	$locations = get_theme_mod( 'nav_menu_locations' );
	if(!empty($locations)){
	    foreach($locations as $location_id){
		    wp_delete_nav_menu($location_id);
        }
    }
}
function cgs_demo_importer_function(){
	$cgs_lite_free_themes = array('default', 'travel', 'pharmacy');
	$active_theme_name = $_POST['active_theme_name'];
	$current_theme = wp_get_theme();
	$current_theme->theme_root;

	clean_data();

	if($active_theme_name == 'default'){
		$footer_copyright = 'Copyright © '.date('Y').' <a href="'.home_url().'">CGS Themes</a>. Theme: <a href="https://www.cgsthemes.com/product-category/free-wordpress-themes/" target="_blank">CGS Lite Default</a> By CGS Themes. Powered by <a href="https://wordpress.org/" target="_blank">WordPress</a>';
    }
	if($active_theme_name == 'travel'){
		$footer_copyright = 'Copyright © '.date('Y').' <a href="'.home_url().'">CGS Themes</a>. Theme: <a href="https://www.cgsthemes.com/product-category/free-wordpress-themes/" target="_blank">CGS Lite Travel</a> By CGS Themes. Powered by <a href="https://wordpress.org/" target="_blank">WordPress</a>';
	}
	if($active_theme_name == 'pharmacy'){
		$footer_copyright = 'Copyright © '.date('Y').' <a href="'.home_url().'">CGS Themes</a>. Theme: <a href="https://www.cgsthemes.com/product-category/free-wordpress-themes/" target="_blank">CGS Lite Pharmacy</a> By CGS Themes. Powered by <a href="https://wordpress.org/" target="_blank">WordPress</a>';
	}
	if($active_theme_name == 'corporate'){
		$footer_copyright = 'Copyright © '.date('Y').' <a href="'.home_url().'">CGS Themes</a>. Theme: <a href="https://www.cgsthemes.com/product-category/free-wordpress-themes/" target="_blank">CGS Lite Corporate</a> By CGS Themes. Powered by <a href="https://wordpress.org/" target="_blank">WordPress</a>';
	}
	if ($active_theme_name == 'delivery-service'){
		$footer_copyright = 'Copyright © '.date('Y').' <a href="'.home_url().'">CGS Themes</a>. Theme: <a href="https://www.cgsthemes.com/product-category/free-wordpress-themes/" target="_blank">CGS Lite Delivery Services</a> By CGS Themes. Powered by <a href="https://wordpress.org/" target="_blank">WordPress</a>';
	}

	if($active_theme_name == 'diner'){
		$footer_copyright = 'Copyright © '.date('Y').' <a href="'.home_url().'">CGS Themes</a>. Theme: <a href="https://www.cgsthemes.com/product-category/free-wordpress-themes/" target="_blank">CGS Lite Diner</a> By CGS Themes. Powered by <a href="https://wordpress.org/" target="_blank">WordPress</a>';
	}
	if($active_theme_name == 'event-planner'){
		$footer_copyright = 'Copyright © '.date('Y').' <a href="'.home_url().'">CGS Themes</a>. Theme: <a href="https://www.cgsthemes.com/product-category/free-wordpress-themes/" target="_blank">CGS Lite Event Planner</a> By CGS Themes. Powered by <a href="https://wordpress.org/" target="_blank">WordPress</a>';
	}

	set_theme_mod('cgs_lite_pro_setting_footer_copyright', $footer_copyright);
	update_option('footer_copyright', $footer_copyright);

	if (in_array($active_theme_name, $cgs_lite_free_themes)) {
		//remove theme file
		$new_local_child_theme_directory = $current_theme->theme_root . '/cgs-lite';
		$old_local_child_theme_directory = $current_theme->theme_root . '/cgs-lite-old';
		rename( $new_local_child_theme_directory, $old_local_child_theme_directory );
		if ( is_dir( $old_local_child_theme_directory ) ) {
			deleteDirectory( $old_local_child_theme_directory );
		}
	}

	////////////////////////////////////////////////////////////
	// Child Theme Install
	if(!is_dir($new_local_child_theme_directory)) {
		if (in_array($active_theme_name, $cgs_lite_free_themes)) {
			if($active_theme_name == 'default'){
				$remote_file_url = 'https://github.com/gitCGSThmes/free_themes/raw/master/cgs-lite-default.zip';
				$local_file      = $current_theme->theme_root . '/cgs-lite-default.zip';
			} elseif($active_theme_name == 'travel') {
				$remote_file_url = 'https://github.com/gitCGSThmes/free_themes/raw/master/cgs-lite-travel.zip';
				$local_file      = $current_theme->theme_root . '/cgs-lite-travel.zip';
			} elseif($active_theme_name == 'pharmacy') {
				$remote_file_url = 'https://github.com/gitCGSThmes/free_themes/raw/master/cgs-lite-pharmacy.zip';
				$local_file      = $current_theme->theme_root . '/cgs-lite-pharmacy.zip';
			} else {
				$remote_file_url = 'https://github.com/gitCGSThmes/free_themes/raw/master/cgs-lite.zip';
				$local_file      = $current_theme->theme_root . '/cgs-lite.zip';
			}
			$copy = copy( $remote_file_url, $local_file );
			if ( ! $copy ) {
				echo "Doh! failed to copy file...\n";
			} else {
				$path = pathinfo( realpath( $local_file ), PATHINFO_DIRNAME );
				$zip = new ZipArchive;
				$res = $zip->open( $local_file );
				if ( $res === true ) {
					$zip->extractTo( $path );
					$zip->close();
					update_option( 'stylesheet', 'cgs-lite' );
					unlink($local_file) or die("Couldn't delete file");
				} else {
					echo "Doh! I couldn't open $local_file";
				}
			}
		}

		if (in_array($active_theme_name, $cgs_lite_free_themes)){
			$import_file = PLUGIN_DIR_PATH.'includes/repo/themes/cgs-lite/'.$active_theme_name.'/site-data.xml';
			$customizer_file = PLUGIN_DIR_PATH.'includes/repo/themes/cgs-lite/'.$active_theme_name.'/customizer-data.dat';
			$widget_file = PLUGIN_DIR_PATH.'includes/repo/themes/cgs-lite/'.$active_theme_name.'/widgets-data.wie';
			update_option('show_theme_banner', 0);
			update_option('show_theme_footer', 0);
		} else {
			$import_file = PLUGIN_DIR_PATH.'includes/repo/themes/elementor/'.$active_theme_name.'/site-data.xml';
			$customizer_file = PLUGIN_DIR_PATH.'includes/repo/themes/elementor/'.$active_theme_name.'/customizer-data.dat';
			update_option('show_theme_banner', 1);
			update_option('show_theme_footer', 1);
			
			$elementor_supported_themes = array('corporate', 'delivery-service', 'diner', 'event-planner');
			$elementor_supported_themes_url = array(
				'https://www.cgsthemes.com/product/corporate/',
				'https://cgsthemesdemo.com/product/delivery-service/',
				'https://cgsthemesdemo.com/product/diner/',
				'https://www.cgsthemes.com/product/event-planner/'
			);
		}

		$wp_import = new TG_WXR_Importer();
		$wp_import->fetch_attachments = true;
		//echo 'media_imported';
		ob_start();
		$response = $wp_import->import( $import_file );
		print('<pre>'.print_r($response).'</pre>');
		ob_end_clean();
		flush_rewrite_rules();
		//echo 'data_imported';

		$data = maybe_unserialize( file_get_contents( $customizer_file ) );
		if (!is_array($data) && (!isset($data['template']) || !isset($data['mods']))){
			echo 'The customizer import file is not in a correct format. Please make sure to use the correct customizer import file.';
		}

		$active_theme_data = wp_get_theme();
		$active_theme = esc_html( $active_theme_data->get( 'TextDomain' ) );
		set_theme_mod('template', $active_theme);

		// If wp_css is set then import it.
		//print_r($data['wp_css']);
		if(isset($data['wp_css']) && !empty($data['wp_css'])){
			wp_update_custom_css_post( $data['wp_css'] );
		}

		// Use a static front page
		$home = get_page_by_title( 'Home' );
		update_option( 'page_on_front', $home->ID );
		update_option( 'show_on_front', 'page' );

		// Loop through theme mods and update them.
		//print_r($data['mods']);
		if (!empty($data['mods'])) {
			foreach ( $data['mods'] as $key => $value ) {
				set_theme_mod( $key, $value );
			}
			//set_theme_mod( 'mods', $data['mods']);
		}
		// Import custom options.
		//print_r($data['options']);
		if ( isset( $data['options'] ) ) {
			foreach ( $data['options'] as $key => $value ) {
				set_theme_mod( $key, $value );
			}
			//echo 'theme_option_imported';
		}

		$main_menu = get_term_by('name', 'Main Menu', 'nav_menu');
		$footer_menu = get_term_by('name', 'Footer Menu', 'nav_menu');
		set_theme_mod( 'nav_menu_locations' , array(
			'primary'   => $main_menu->term_id,
			'footer_menu' => $footer_menu->term_id
		));

		if (in_array($active_theme_name, $cgs_lite_free_themes)) {
			$widget_file = PLUGIN_DIR_PATH.'includes/repo/themes/cgs-lite/'.$active_theme_name.'/widgets-data.wie';
			$widget_data = file_get_contents( $widget_file );
			if ( ! empty( $widget_data ) ) {
				$widget_data_object = json_decode( $widget_data, true );
				foreach ( $widget_data_object as $widget_key => $widget_value ) {
					$sidebar_id                    = $widget_key;
					$add_to_sidebar[ $sidebar_id ] = array();
					foreach ( $widget_value as $key => $value ) {
						$key         = explode( '-1', $key );
						$key         = explode( '-2', $key[0] );
						$key         = explode( '-3', $key[0] );
						$key         = explode( '-4', $key[0] );
						$widget_id   = $key[0];
						$widget_data = $value;
						$temp_array  = array(
							'id_base'  => $widget_id,
							'instance' => $widget_data
						);
						array_push( $add_to_sidebar[ $sidebar_id ], $temp_array );
					}
				}
				if ( ! empty( $add_to_sidebar[ $sidebar_id ] ) ) {
					auto_add_sidebar_widgets( $add_to_sidebar, $ignore_sidebar_with_content = true );
				}
			}
		}
		$cart_page_id = get_id_by_slug('cart');
		update_option('woocommerce_cart_page_id', $cart_page_id);
		
		$checkout_page_id = get_id_by_slug('checkout');
		update_option('woocommerce_checkout_page_id', $checkout_page_id);
		
		$myaccount_page_id = get_id_by_slug('my-account');
		update_option('woocommerce_myaccount_page_id', $myaccount_page_id);
		
		$terms_page_id = get_id_by_slug();
		update_option('woocommerce_terms_page_id', $terms_page_id);

		/*$wpmenucart = 'a:8:{s:11:"shop_plugin";s:11:"woocommerce";s:10:"menu_slugs";a:1:{i:1;s:9:"main-menu";}s:14:"always_display";s:1:"1";s:12:"icon_display";s:1:"1";s:9:"cart_icon";s:1:"0";s:13:"items_display";s:1:"1";s:15:"items_alignment";s:5:"right";s:16:"total_price_type";s:5:"total";}';
		update_option('wpmenucart', $wpmenucart);*/

		echo 'ok';
	} else {
		echo 'Directory not deleted';
	}
	die();
}
function get_id_by_slug($page_slug) {
    $page = get_page_by_path($page_slug);
    if ($page) {
        return $page->ID;
    } else {
        return null;
    }
} 
function cgs_demo_importer_message(){
	$active_theme_name = $_POST['active_theme_name'];

	$to1 = 'jagannathcoregen@gmail.com';
	//$to1 = 'info@coregensolutions.com';
	$from1 = get_option('admin_email');
	$headers1 = 'From: '.$from1. "\r\n";
	$headers1 .= "MIME-Version: 1.0\n";
	$headers1 .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	$subject1 = "Demo Import Clicked on ".$active_theme_name;
	$msg1 = "Dear Admin,<br><br>Demo Import Button Clicked on ".$active_theme_name.'<br><br><strong>Admin Email:</strong> '.$from1.'<br><br><strong>Site URL: </strong>'.home_url();
	wp_mail( $to1, $subject1, $msg1, $headers1 );
	die();
}
function cgs_demo_latest_blog($atts){
	ob_start();
	$return_string = '';
	extract( shortcode_atts( array(
		'blog_style' => '',     // '', 'masonry', 'masonry2', 'fullwide'
		'number_of_posts' => '-1',      // -1 == all posts
		'category_id' => '',      // '' == all category
		'post__not_in' => array(1),
	), $atts ) );

	if(!empty($category_id)){
		$blog_args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page' => $number_of_posts,
			'cat' => $category_id,
			'post__not_in' => array(1),
		);
	} else {
		$blog_args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page' => $number_of_posts,
			'post__not_in' => array(1),
		);
	}

	$blog_data = new WP_Query($blog_args);
	if($blog_data->have_posts()){
		while($blog_data->have_posts()) : $blog_data->the_post();
			$return_string .= '<div class="latestblog-wrapper">';
			if(has_post_thumbnail()){
				$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => '' ) );
			} else {
				$post_thumbnail = '';
			}
			$post_categories = wp_get_post_categories(get_the_ID());
			$catname = '';
			if(!empty($post_categories)){
				foreach($post_categories as $pc){
					$cat = get_category( $pc );
					$catname .= $cat->name.', ';
				}
			}
			$return_string .= '<a href="'.get_permalink().'">'.$post_thumbnail.'</a>';
			$return_string .= '<h2><a href="'.get_permalink().'">'.get_the_title().'</a></h2>';
			$return_string .= '<div class="custom-post-meta">'.get_the_time('M j, Y').' | '.$catname.' | '.get_the_author_meta('display_name').'</div>';
			$return_string .= get_the_excerpt();
			$return_string .= '<div class="readmore"><a href="'.get_the_permalink().'">Read More</a></div>';
			$return_string .= '</div>';
		endwhile;
	}
	wp_reset_postdata();
	return $return_string;
}
add_shortcode('cgs-demo-latest-blog', 'cgs_demo_latest_blog');

add_filter( 'woocommerce_add_to_cart_fragments', 'iconic_cart_count_fragments', 10, 1 );
function iconic_cart_count_fragments( $fragments ) {
	$fragments['li.cart'] = '<li class="cart menu-item menu-item-type-post_type menu-item-object-page"><a href="' . get_permalink( wc_get_page_id( 'cart' ) ) . '"><i class="fa fa-shopping-bag"></i>'.WC()->cart->get_cart_contents_count().'</a></li>';
	return $fragments;
}

add_action( 'wp_head', 'dcwd_cart_count_styles' );
function dcwd_cart_count_styles() {
	?>
    <style>
        #menu-main-menu .cart { position: relative; }
        #menu-main-menu .count { background: #666; color: #fff; border-radius: 2em; height: 18px; line-height: 18px; position: absolute; right: 5px; text-align: center; top: 75%; transform: translateY(-100%) translateX(15%); width: 18px; }
    </style>
	<?php
}
add_filter( 'wp_nav_menu_main-menu_items', 'am_append_cart_icon', 10, 2 );
function am_append_cart_icon( $items, $args ) {
	$cart_item_count = WC()->cart->get_cart_contents_count();
	$cart_count_span = '';
	if ( $cart_item_count ) {
		$cart_count_span = '<span class="count">'.$cart_item_count.'</span>';
	}
	$cart_link = '<li class="cart menu-item menu-item-type-post_type menu-item-object-page"><a href="' . get_permalink( wc_get_page_id( 'cart' ) ) . '"><i class="fa fa-shopping-bag"></i>'.$cart_count_span.'</a></li>';
	// Add the cart link to the end of the menu.
	$items = $items . $cart_link;
	return $items;
}
