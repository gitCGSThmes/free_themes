<?php
$codemirror_url = plugins_url('newsletter') . '/vendor/codemirror';
?>
<link href="<?php echo $codemirror_url ?>/codemirror.css" type="text/css" rel="stylesheet">
<link href="<?php echo $codemirror_url ?>/addon/hint/show-hint.css" type="text/css" rel="stylesheet">
<script src="<?php echo $codemirror_url ?>/codemirror.js"></script>
<script src="<?php echo $codemirror_url ?>/mode/xml/xml.js"></script>
<script src="<?php echo $codemirror_url ?>/mode/css/css.js"></script>
<script src="<?php echo $codemirror_url ?>/mode/javascript/javascript.js"></script>
<script src="<?php echo $codemirror_url ?>/mode/htmlmixed/htmlmixed.js"></script>
<script src="<?php echo $codemirror_url ?>/addon/hint/show-hint.js"></script>
<script src="<?php echo $codemirror_url ?>/addon/hint/xml-hint.js"></script>
<script src="<?php echo $codemirror_url ?>/addon/hint/html-hint.js"></script>