<?php /* Template Name: Full Wide with Container */ ?>
<?php get_header(); ?>
<?php
$cgs_animal_shelter_show_inner_banner = get_post_meta(get_the_ID(), 'cgs_animal_shelter_show_inner_banner', true);
$cgs_animal_shelter_banner_image = get_field('cgs_animal_shelter_banner_image');
$cgs_animal_shelter_title_on_banner = get_post_meta(get_the_ID(), 'cgs_animal_shelter_title_on_banner', true);
$cgs_animal_shelter_title_color = get_post_meta(get_the_ID(), 'cgs_animal_shelter_title_color', true);
$cgs_animal_shelter_title_alignment = get_post_meta(get_the_ID(), 'cgs_animal_shelter_title_alignment', true);
?>

<?php if($cgs_animal_shelter_show_inner_banner == 'yes' || $cgs_animal_shelter_show_inner_banner == ''){ ?>
    <div class="inner-banner" style="background: url('<?php echo $cgs_animal_shelter_banner_image; ?>')">
        <div class="container">
            <h1 style="color: <?php echo $cgs_animal_shelter_title_color; ?>; text-align: <?php echo $cgs_animal_shelter_title_alignment; ?>;"><?php echo $cgs_animal_shelter_title_on_banner; ?></h1>
        </div>
    </div>
    <style>
        .inner-banner h1:after{
            border-top: 1px solid <?php echo $cgs_animal_shelter_title_color; ?>;
        }
    </style>
<?php } ?>
	<div class="main-content-wrapper">
		<div class="container">
		<?php if(have_posts()){ ?>
			<?php while(have_posts()) : the_post(); ?>
				<?php if(empty($cgs_animal_shelter_title_on_banner)){ ?>
                    <h1><?php the_title(); ?></h1>
				<?php } ?>
				<?php get_template_part( 'content' ); ?>
			<?php endwhile; ?>
		<?php } ?>
		</div>
	</div>
<?php get_footer(); ?>
