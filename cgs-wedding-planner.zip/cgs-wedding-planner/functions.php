<?php
if ( ! function_exists( 'cgs_wedding_planner_setup' ) ) :
	function cgs_wedding_planner_setup(){
        require get_template_directory() . '/includes/about-themes.php';
        require_once get_template_directory() . '/includes/bs4navwalker.php';
        require get_template_directory() . '/includes/customizer.php';
        require get_template_directory() . '/includes/bs4shortcodes.php';
        require get_template_directory() . '/includes/tgmp/class-tgm-plugin-activation.php';
        require_once get_template_directory() . '/includes/metaboxes.php';
        require get_template_directory() . '/includes/class_cgs_themes_admin_importer.php';

        if ( ! isset( $content_width ) ) {
            $content_width = 725;
        }

        add_theme_support( 'woocommerce' );
        add_theme_support( 'bbpress' );
        add_theme_support( 'automatic-feed-links' );
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'title-tag' );
        add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

        add_theme_support( 'custom-background', apply_filters( 'basic_custom_background_args', array( 'default-color' => 'ffffff' ) ) );
        add_theme_support( 'custom-header', array(
            'width'       => 1080,
            'height'      => 190,
            'flex-height' => true,
            'flex-width' => true,
        ) );
        add_image_size( 'img_348_201', 348, 201, true );

        $args = array();
        $lpos = esc_html(get_theme_mod( 'display_logo_and_title' ));
        if ( false === $lpos || 'image' == $lpos ) {
            $args['header-text'] = array( 'blog-name' );
        }
        add_theme_support( 'custom-logo', $args );

        load_theme_textdomain( 'cgs-wedding-planner', get_template_directory() . '/languages' );

		register_nav_menus( array(
			'primary'    	=> __( 'Main Menu', 'cgs-wedding-planner' ),
			'footer_menu'   => __('Footer Menu', 'cgs-wedding-planner')
		) );
		/* translators: %s: search term */
		register_sidebar( array(
			'name' => __('Footer Widget 1', 'cgs-wedding-planner'),
			'id' => 'footer-widget-1',
			'before_widget' => '<div id="%1$s" class="widget_box cgs_widget_box %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="side_title">',
			'after_title' => '</h3>',
		) );
		/* translators: %s: search term */
		register_sidebar( array(
			'name' => __('Footer Widget 2', 'cgs-wedding-planner'),
			'id' => 'footer-widget-2',
			'before_widget' => '<div id="%1$s" class="widget_box cgs_widget_box %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="side_title">',
			'after_title' => '</h3>',
		) );
		/* translators: %s: search term */
		register_sidebar( array(
			'name' => __('Footer Widget 3', 'cgs-wedding-planner'),
			'id' => 'footer-widget-3',
			'before_widget' => '<div id="%1$s" class="widget_box cgs_widget_box %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="side_title">',
			'after_title' => '</h3>',
		) );
		/* translators: %s: search term */
		register_sidebar( array(
			'name' => __('Contant Page Sidebar', 'cgs-wedding-planner'),
			'id' => 'contact-page-sidebar',
			'before_widget' => '<div id="%1$s" class="widget_box cgs_widget_box %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="side_title">',
			'after_title' => '</h3>',
		) );
		/* translators: %s: search term */
		register_sidebar( array(
			'name' => __('Primary Sidebar', 'cgs-wedding-planner'),
			'id' => 'sidebar-1',
			'before_widget' => '<div id="%1$s" class="widget_box %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="side_title">',
			'after_title' => '</h3>',
		) );
	}
endif;
add_action( 'after_setup_theme', 'cgs_wedding_planner_setup' );
add_action( 'tgmpa_register', 'cgs_wedding_planner_require_plugins' );
function cgs_wedding_planner_require_plugins(){
	$config = array(
		'id'           => 'cgs-wedding-planner-tgmpa', // your unique TGMPA ID
		'default_path' => get_stylesheet_directory() . '/includes/plugins/', // default absolute path
		'menu'         => 'cgs-wedding-planner-require-plugins', // menu slug
		'has_notices'  => true, // Show admin notices
		'dismissable'  => false, // the notices are NOT dismissable
		'dismiss_msg'  => '', // this message will be output at top of nag
		'is_automatic' => true, // automatically activate plugins after installation
		'message'      => '<!--Hey there.-->', // message to output right before the plugins table
		'strings'      => array() // The array of message strings that TGM Plugin Activation uses
	);

	$plugins = array(
		array(
			'name'               => 'Contact Form 7',
			'slug'               => 'contact-form-7',
			'required'           => true, // this plugin is required
			'force_activation'   => true, // this plugin is going to stay activated unless the user switches to another theme
		),
		array(
			'name'               => 'Easy Google Fonts',
			'slug'               => 'easy-google-fonts',
			'required'           => true, // this plugin is required
			'force_activation'   => true, // this plugin is going to stay activated unless the user switches to another theme
		),
		array(
			'name'               => 'Newsletter',
			'slug'               => 'newsletter',
			'required'           => true, // this plugin is required
			'force_activation'   => true, // this plugin is going to stay activated unless the user switches to another theme
		),
		array(
			'name'               => 'Smart Slider 3',
			'slug'               => 'smart-slider-3',
			'required'           => false, // this plugin is required
			'force_activation'   => false, // this plugin is going to stay activated unless the user switches to another theme
		),
	);
	tgmpa( $plugins, $config );
}

function cgs_wedding_planner_enqueue_scripts() {
	wp_enqueue_style( 'cgs-wedding-planner-fonts', 'https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,800|Open+Sans:400,600,700&display=swap', array(), true );
	wp_enqueue_style( 'cgs-wedding-planner-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), true );
    wp_enqueue_style( 'cgs-wedding-planner-bootstrap-css', get_template_directory_uri().'/assets/css/bootstrap.min.css', array(), true );
	wp_enqueue_style( 'cgs-wedding-planner-infinite-slider-style', get_stylesheet_directory_uri() . '/assets/css/infinite-slider.css');
	wp_enqueue_style( 'cgs-wedding-planner-bxslider', get_stylesheet_directory_uri() . '/assets/css/jquery.bxslider.min.css');
    wp_enqueue_style( 'cgs-wedding-planner-style', get_stylesheet_uri(), array(), true );

    wp_enqueue_script( 'cgs-wedding-planner-html5shiv', get_template_directory_uri() . '/assets/js/html5shiv.min.js', false, '3.7.3', true );
    wp_script_add_data( 'cgs-wedding-planner-html5shiv', 'conditional', 'lt IE 9' );
    wp_enqueue_script( 'cgs-wedding-planner-bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array( 'jquery' ), true, true );
	wp_enqueue_script( 'cgs-wedding-planner-slick', get_template_directory_uri() . '/assets/js/slick.js', array( 'jquery' ), true, true );
	wp_enqueue_script( 'cgs-wedding-planner-bxslider', get_template_directory_uri() . '/assets/js/jquery.bxslider.min.js', array( 'jquery' ), true, true );
	wp_enqueue_script( 'cgs-wedding-planner-bootstrap-masonry', get_template_directory_uri() . '/assets/js/bootstrap4.masonry.min.js', array( 'jquery' ), true, true );
	wp_enqueue_script( 'cgs-wedding-planner-parallax-min-js', get_template_directory_uri() . '/assets/js/parallax.min.js', array( 'jquery' ), true, true );
	wp_enqueue_script( 'cgs-wedding-planner-themescript', get_template_directory_uri() . '/assets/js/themescript.js', array( 'jquery' ), true, true );
}
add_action( 'wp_enqueue_scripts', 'cgs_wedding_planner_enqueue_scripts' );

add_action( 'init', 'cgs_create_post_type' );
function cgs_create_post_type() {
	$our_team_labels = array(
		'name' => esc_html__('Our Team', 'cgs-lite-pro'),
		'singular_name' => esc_html__('Our Team', 'cgs-lite-pro'),
		'add_new' => esc_html__('Add New', 'cgs-lite-pro'),
		'add_new_item' => esc_html__('Add New Team', 'cgs-lite-pro'),
		'edit_item' => esc_html__('Edit Team', 'cgs-lite-pro'),
		'new_item' => esc_html__('New Team', 'cgs-lite-pro'),
		'view_item' => esc_html__('View Team', 'cgs-lite-pro'),
		'search_items' => esc_html__('Search Team', 'cgs-lite-pro'),
		'not_found' => esc_html__('Nothing found', 'cgs-lite-pro'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'cgs-lite-pro'),
		'parent_item_colon' => ''
	);
	$our_team_args = array(
		'labels' => $our_team_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => 'dashicons-admin-tools',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title','editor','thumbnail')
	);
	register_post_type( 'cgs-our-team' , $our_team_args );

	$our_clients_labels = array(
		'name' => esc_html__('Our Clients', 'cgs-lite-pro'),
		'singular_name' => esc_html__('Our Client', 'cgs-lite-pro'),
		'add_new' => esc_html__('Add Client', 'cgs-lite-pro'),
		'add_new_item' => esc_html__('Add New Client', 'cgs-lite-pro'),
		'edit_item' => esc_html__('Edit Client', 'cgs-lite-pro'),
		'new_item' => esc_html__('New Client', 'cgs-lite-pro'),
		'view_item' => esc_html__('View Client', 'cgs-lite-pro'),
		'search_items' => esc_html__('Search Client', 'cgs-lite-pro'),
		'not_found' => esc_html__('Nothing found', 'cgs-lite-pro'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'cgs-lite-pro'),
		'parent_item_colon' => ''
	);
	$our_clients_args = array(
		'labels' => $our_clients_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => 'dashicons-admin-tools',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title','editor','thumbnail')
	);
	register_post_type( 'cgs-our-clients' , $our_clients_args );

	$testimonial_labels = array(
		'name' => esc_html__('Testimonials', 'cgs-lite-pro'),
		'singular_name' => esc_html__('Testimonial', 'cgs-lite-pro'),
		'add_new' => esc_html__('Add New', 'cgs-lite-pro'),
		'add_new_item' => esc_html__('Add New Testimonial', 'cgs-lite-pro'),
		'edit_item' => esc_html__('Edit Testimonial', 'cgs-lite-pro'),
		'new_item' => esc_html__('New Testimonial', 'cgs-lite-pro'),
		'view_item' => esc_html__('View Testimonial', 'cgs-lite-pro'),
		'search_items' => esc_html__('Search Testimonial', 'cgs-lite-pro'),
		'not_found' => esc_html__('Nothing found', 'cgs-lite-pro'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'cgs-lite-pro'),
		'parent_item_colon' => ''
	);
	$testimonial_args = array(
		'labels' => $testimonial_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => 'dashicons-admin-tools',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title','editor','thumbnail')
	);
	register_post_type( 'cgs-testimonials' , $testimonial_args );

	$services_labels = array(
		'name' => esc_html__('Services', 'cgs-lite-pro'),
		'singular_name' => esc_html__('Service', 'cgs-lite-pro'),
		'add_new' => esc_html__('Add New', 'cgs-lite-pro'),
		'add_new_item' => esc_html__('Add New Service', 'cgs-lite-pro'),
		'edit_item' => esc_html__('Edit Service', 'cgs-lite-pro'),
		'new_item' => esc_html__('New Service', 'cgs-lite-pro'),
		'view_item' => esc_html__('View Service', 'cgs-lite-pro'),
		'search_items' => esc_html__('Search Service', 'cgs-lite-pro'),
		'not_found' => esc_html__('Nothing found', 'cgs-lite-pro'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'cgs-lite-pro'),
		'parent_item_colon' => ''
	);
	$services_args = array(
		'labels' => $services_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => 'dashicons-admin-tools',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title')
	);
	register_post_type( 'cgs-services' , $services_args );

	$cgs_pricing_table_labels = array(
		'name' => esc_html__('Pricing Table', 'cgs-lite-pro'),
		'singular_name' => esc_html__('Pricing Table', 'cgs-lite-pro'),
		'add_new' => esc_html__('Add New', 'cgs-lite-pro'),
		'add_new_item' => esc_html__('Add New Pricing Table', 'cgs-lite-pro'),
		'edit_item' => esc_html__('Edit Pricing Table', 'cgs-lite-pro'),
		'new_item' => esc_html__('New Pricing Table', 'cgs-lite-pro'),
		'view_item' => esc_html__('View Pricing Table', 'cgs-lite-pro'),
		'search_items' => esc_html__('Search Pricing Table', 'cgs-lite-pro'),
		'not_found' => esc_html__('Nothing found', 'cgs-lite-pro'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'cgs-lite-pro'),
		'parent_item_colon' => ''
	);
	$cgs_pricing_table_args = array(
		'labels' => $cgs_pricing_table_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => 'dashicons-admin-tools',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title')
	);
	register_post_type( 'cgs-pricing-table' , $cgs_pricing_table_args );
}

function excerpt($limit) {
	$excerpt = explode(' ', get_the_excerpt(), $limit);
	if (count($excerpt)>=$limit) {
		array_pop($excerpt);
		$excerpt = implode(" ",$excerpt).'...';
	} else {
		$excerpt = implode(" ",$excerpt);
	}
	$excerpt = preg_replace('`[[^]]*]`','',$excerpt);
	return $excerpt;
}

add_action('admin_enqueue_scripts', 'cgs_fashion_trend_admin_theme_style');
function cgs_fashion_trend_admin_theme_style() {
    wp_enqueue_style('cgs-theme-admin-style', get_template_directory_uri() . '/assets/css/admin_style.css');
}
add_action( 'admin_init', function() {
    if ( did_action( 'elementor/loaded' ) ) {
        remove_action( 'admin_init', [ \Elementor\Plugin::$instance->admin, 'maybe_redirect_to_getting_started' ] );
    }
}, 1 );
add_filter( 'woocommerce_helper_suppress_admin_notices', '__return_true' );
add_filter( 'woocommerce_helper_suppress_admin_notices', 'filter_function_name_3027' );
function filter_function_name_3027( $false ){
	return $false;
}
add_filter( 'woocommerce_prevent_automatic_wizard_redirect', 'wc_subscriber_auto_redirect', 20, 1 );
function wc_subscriber_auto_redirect( $boolean ) {
    return true;
}
function iap_wc_bootstrap_form_field_args ($args, $key, $value) { 
  $args['input_class'][] = 'form-control'; 
  return $args; 
}
add_filter('woocommerce_form_field_args','iap_wc_bootstrap_form_field_args', 10, 3);